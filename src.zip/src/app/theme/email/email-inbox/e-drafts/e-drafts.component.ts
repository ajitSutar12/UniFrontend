import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-drafts',
  templateUrl: './e-drafts.component.html',
  styleUrls: [
    './e-drafts.component.scss'
  ]
})
export class EDraftsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
