import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-sent',
  templateUrl: './e-sent.component.html',
  styleUrls: [
    './e-sent.component.scss'
  ]
})
export class ESentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
