import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-main',
  templateUrl: './e-main.component.html',
  styleUrls: [
    './e-main.component.scss'
  ]
})
export class EMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
