import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-read',
  templateUrl: './email-read.component.html',
  styleUrls: ['./email-read.component.scss']
})
export class EmailReadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
