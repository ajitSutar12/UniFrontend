import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentregisteration',
  templateUrl: './studentregisteration.component.html',
  styleUrls: ['./studentregisteration.component.scss']
})
export class StudentregisterationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
