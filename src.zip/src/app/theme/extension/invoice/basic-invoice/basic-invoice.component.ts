import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-invoice',
  templateUrl: './basic-invoice.component.html',
  styleUrls: ['./basic-invoice.component.scss']
})
export class BasicInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
