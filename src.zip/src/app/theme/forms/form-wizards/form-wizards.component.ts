import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-wizards',
  templateUrl: './form-wizards.component.html',
  styleUrls: ['./form-wizards.component.scss']
})
export class FormWizardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
