import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-navbar-lg',
  templateUrl: './wizard-navbar-lg.component.html',
  styleUrls: ['./wizard-navbar-lg.component.scss']
})
export class WizardNavbarLgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
