import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-on',
  templateUrl: './add-on.component.html',
  styleUrls: [
    './add-on.component.scss'
  ]
})
export class AddOnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
