import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anybody',
  templateUrl: './anybody.component.html',
  styleUrls: ['./anybody.component.scss']
})
export class AnybodyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
