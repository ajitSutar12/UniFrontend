import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anybodydraft',
  templateUrl: './anybodydraft.component.html',
  styleUrls: ['./anybodydraft.component.scss']
})
export class AnybodydraftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
