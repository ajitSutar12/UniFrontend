import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collegedraft',
  templateUrl: './collegedraft.component.html',
  styleUrls: ['./collegedraft.component.scss']
})
export class CollegedraftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
