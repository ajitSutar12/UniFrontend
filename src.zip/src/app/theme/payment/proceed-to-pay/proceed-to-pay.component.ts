import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proceed-to-pay',
  templateUrl: './proceed-to-pay.component.html',
  styleUrls: ['./proceed-to-pay.component.scss']
})
export class ProceedToPayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
