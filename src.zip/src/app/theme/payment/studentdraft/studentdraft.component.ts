import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentdraft',
  templateUrl: './studentdraft.component.html',
  styleUrls: ['./studentdraft.component.scss']
})
export class StudentdraftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
