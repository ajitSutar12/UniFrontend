import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-radial',
  templateUrl: './radial.component.html',
  styleUrls: [
    './radial.component.scss',
    '../../../../assets/charts/radial/css/radial.scss'
  ],
  encapsulation: ViewEncapsulation.None
})
export class RadialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
